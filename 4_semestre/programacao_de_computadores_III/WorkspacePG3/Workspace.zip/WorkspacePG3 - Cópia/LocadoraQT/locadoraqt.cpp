#include "locadoraqt.h"

LocadoraQT::LocadoraQT(QWidget *parent)
    : QWidget(parent)
{
	ui.setupUi(this);
}

LocadoraQT::~LocadoraQT()
{

}
