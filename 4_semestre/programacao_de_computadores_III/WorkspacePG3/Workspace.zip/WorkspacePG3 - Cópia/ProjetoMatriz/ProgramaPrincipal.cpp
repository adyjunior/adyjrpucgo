#include"Interface.h"


int main(){

	PC3::Interface show;
	show.menuPrincipal();


system("pause");

}
