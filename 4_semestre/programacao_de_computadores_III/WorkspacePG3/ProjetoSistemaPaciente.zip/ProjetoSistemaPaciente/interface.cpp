#include "interface.h"
#include "ui_interface.h"
#include<QIcon>

interface::interface(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::interface)
{
    ui->setupUi(this);

    //conecçao(nomeDoBotao,sinalRecebido,objetoQueVaiSerUsado,metodoSlot);
    this->connect(ui->btnGravar,SIGNAL(clicked()),this,SLOT(gravarPaciente()));
    //this->connect(ui->lineEdit,SIGNAL(textChanged(QString)),this,SIGNAL());
    this->connect(ui->btnExcluir,SIGNAL(clicked()),this,SLOT(excluirPaciente()));
    this->connect(ui->btnListar,SIGNAL(clicked()),this,SLOT(listarPaciente()));
    this->connect(ui->boxIdioma,SIGNAL(currentIndexChanged(int)),this,SLOT(escolhaIdiomas()));

    this->ui->edtNome->setFocus();


}

interface::~interface()
{
    delete ui;
}


void interface::escolhaIdiomas(){

    int opcao = ui->boxIdioma->currentIndex();


    switch(opcao){
    case 0:{
            ui->lblNome->setText("Nome");
            ui->lblData->setText("Data de nascimento");
            ui->lblTelefone->setText("Telefone");
            ui->lblEndereco->setText("Endere�o");
            ui->lblEmail->setText("Email");
            ui->lblCPF->setText("CPF");
            ui->lblIdioma->setText("Idioma");
            ui->btnExcluir->setText("Excluir");
            ui->btnGravar->setText("Gravar");
            ui->btnListar->setText("Listar");
            ui->tabWidget->setTabText(0,"Dados");
            ui->tabWidget->setTabText(1,"Pacientes");
            ui->lblSistemaPaciente->setText("Sistema Paciente");
            ui->btnAlterar->setText("Alterar Dados");
            ui->btnMostrar->setText("Exibir Dados");
            this->setWindowTitle("Sistema Paciente");


            break;
        }
    case 1:{
            ui->lblNome->setText("Name");
            ui->lblData->setText("Date of birth");
            ui->lblTelefone->setText("Telephone");
            ui->lblEndereco->setText("Address");
            ui->lblEmail->setText("Email");
            ui->lblCPF->setText("CPF");
            ui->lblIdioma->setText("Language");
            ui->btnExcluir->setText("Delete");
            ui->btnGravar->setText("Save");
            ui->btnListar->setText("List");
            ui->tabWidget->setTabText(0,"Data");
            ui->tabWidget->setTabText(1,"Patients");
            ui->lblSistemaPaciente->setText("System Patients");
            ui->btnAlterar->setText("Change Data");
            ui->btnMostrar->setText("View Data");
            this->setWindowTitle("System Patients");

            break;
        }
    case 2:{
            ui->lblNome->setText("Nombre");
            ui->lblData->setText("Fecha de nacimiento");
            ui->lblTelefone->setText("Tel�fono");
            ui->lblEndereco->setText("Direcci�n");
            ui->lblEmail->setText("Email");
            ui->lblCPF->setText("CPF");
            ui->lblIdioma->setText("Idioma");
            ui->btnExcluir->setText("Eliminar");
            ui->btnGravar->setText("Guardar");
            ui->btnListar->setText("Lista");
            ui->tabWidget->setTabText(0,"Datos");
            ui->tabWidget->setTabText(1,"Los pacientes");
            ui->lblSistemaPaciente->setText("Sistema de Pacientes");
            ui->btnAlterar->setText("Cambiar datos");
            ui->btnMostrar->setText("Vista de datos");
            this->setWindowTitle("Sistema de Pacientes");

            break;
        }
    case 3:{
            ui->lblNome->setText("Name");
            ui->lblData->setText("Geburtsdatum");
            ui->lblTelefone->setText("Telefon");
            ui->lblEndereco->setText("Adresse");
            ui->lblEmail->setText("E-Mail");
            ui->lblCPF->setText("CPF");
            ui->lblIdioma->setText("Sprache");
            ui->btnExcluir->setText("L�schen");
            ui->btnGravar->setText("Speichern");
            ui->btnListar->setText("Liste");
            ui->tabWidget->setTabText(0,"Daten");
            ui->tabWidget->setTabText(1,"Patienten");
            ui->lblSistemaPaciente->setText("System Patienten");
            ui->btnAlterar->setText("Change Data");
            ui->btnMostrar->setText("View Data");
            //this->setWindowTitle("System Patienten");

            break;
        }
    default:{
            break;
        }
    }



}

void interface::texto(){
   ui->edtListar->setText( ui->listPaciente->currentItem()->text() );
}


void interface::listarPaciente(){

    this->erro = PC3::ERROS::getInstancia(ui->boxIdioma->currentIndex());
    QMessageBox msg;

    try{


        ui->listPaciente->clear();
        PSP::Paciente *pessoa;
        Container::Iterator<PSP::Paciente*> *it;
        int i;

        it = ctrl.listarPaciente();


        pessoa = it->primeiro();
        for(i=0;it->existeProximo();i++){

            this->ui->listPaciente->addItem(QString::fromStdString(pessoa->getNome()));
            //this->nomes.insert(i, QString::fromStdString(pessoa->getNome()));
            pessoa = it->proximo();
        }

        pessoa = it->itemAtual();
        this->ui->listPaciente->addItem(QString::fromStdString(pessoa->getNome()));
        //this->nomes.insert(i,QString::fromStdString(pessoa->getNome()));

        ui->listPaciente->sortItems();
        //this->nomes.sort();
        //ui->listPaciente->count();

        //delete it;

    }catch(int valorErro){
        QString texto,valor;
        valor.setNum(valorErro);
        texto = QString::fromStdString(erro->getErro(valorErro));
        msg.setIcon(QMessageBox::Critical);
        msg.setText(texto);
        msg.exec();
    }catch(std::logic_error a){
        QMessageBox msg;
        QString texto;
        texto.fromStdString(a.what());

        msg.setText("Erro [5000] "+texto);
        msg.exec();
    }

/*
    //QListWidgetItem *newItem = new QListWidgetItem;
    //newItem->setText("POAKSPOA");
    //listWidget->insertItem(5, newItem);

    //ui->listPaciente->insertItem(3,"LIST WIDGET");
    //ui->listPaciente->addItem("VILAAAA");
    //ui->listPaciente->addItem("JUNIOR");
    //ui->listPaciente->addItem("TIGRAAAO");
    //ui->listPaciente->sortItems();

    //ui->listPaciente->itemClicked(newItem);
 */
}



void interface::alteraPaciente(){
    this->erro = PC3::ERROS::getInstancia(ui->boxIdioma->currentIndex());
    QMessageBox msg;


}

void interface::excluirPaciente(){
    this->erro = PC3::ERROS::getInstancia(ui->boxIdioma->currentIndex());
    QMessageBox msg;

    QString alerta,s,n,sucesso;
    if(ui->boxIdioma->currentIndex() == 1){
        alerta = "Are you sure you want to delete patient data : ";s="Yes";n="No";sucesso = "Patient successfully deleted!";}
    else if(ui->boxIdioma->currentIndex() == 2){
        alerta = "Est� seguro que desea eliminar los datos del paciente : ";s="S�";n="No";sucesso = "El paciente se ha eliminado correctamente!";}
    else if(ui->boxIdioma->currentIndex() == 3){
        alerta = "Sind Sie sicher, dass Sie auf Patientendaten zu l�schen : ";s="Ja";n="Nein";sucesso = "Patient erfolgreich gel�scht!";}
    else{
        alerta = "Tem certeza que deseja excluir os dados do paciente : ";s="Sim";n="N�o";sucesso = "Paciente excluido com sucesso !";}


    try{
        if(ui->edtListar->text() == "")
            throw(13);

        QMessageBox msgBox,msgPos;
        QPushButton *connectButton = msgBox.addButton(tr(s.toAscii()), QMessageBox::ActionRole);
        msgBox.addButton(tr(n.toAscii()),QMessageBox::ActionRole);
        msgBox.setText(alerta + ui->edtListar->text()+ "?");

        msgBox.setIcon(QMessageBox::Warning);

        msgBox.exec();

        if (msgBox.clickedButton() == connectButton) {
            QString nome = this->ui->edtListar->text();
            ctrl.exclusaoPaciente(nome.toStdString());
            msgPos.setText(sucesso);
            msgPos.exec();
            this->listarPaciente();
            ui->edtListar->clear();

        }




    }catch(int valorErro){
        QString texto,valor;
        valor.setNum(valorErro);
        texto = QString::fromStdString(erro->getErro(valorErro));
        msg.setIcon(QMessageBox::Critical);
        msg.setText(texto);
        msg.exec();
    }catch(std::logic_error a){
        QMessageBox msg;
        QString texto;
        texto.fromStdString(a.what());

        msg.setText("Erro [5000] "+texto);
        msg.exec();
    }
}

void interface::gravarPaciente(){

    this->erro = PC3::ERROS::getInstancia(ui->boxIdioma->currentIndex());

   QString nome =  this->ui->edtNome->text();
   QString telefone = this->ui->edtTelefone->text();
   QString numeroCPF = this->ui->edtCPF->text();
   QString endereco = this->ui->edtEndereco->text();
   QString email  = this->ui->edtEmail->text();

   QMessageBox msg;
   QString alerta;

   if(ui->boxIdioma->currentIndex() == 1)alerta = "The patient was successfully saved !";
   else if(ui->boxIdioma->currentIndex() == 2)alerta = "El paciente se salv� con �xito";
   else if(ui->boxIdioma->currentIndex() == 3)alerta = "Der Patient wurde erfolgreich gespeichert !";
   else alerta = "Paciente foi gravado com sucesso !";

   try{
       int d=0,m=0,a=0;
       std::string data="";

       if( !(ui->edtData->text() == "//") ){
           data = this->ui->edtData->text().toStdString();


           d = atoi(data.substr(0,2).c_str());
           m = atoi(data.substr(3,2).c_str());
           a = atoi(data.substr(6,4).c_str());

       }


       PSP::Paciente paciente;


       paciente.setNome(nome.toStdString());
       if(telefone == "")paciente.setTelefone(0);
       else paciente.setTelefone(telefone.toLong());
       if(numeroCPF == "")paciente.setNumeroCPF(0);
       else paciente.setNumeroCPF(numeroCPF.toLongLong());
       if(data == "") paciente.setDataDeNascimento(1,10,5783);
       else paciente.setDataDeNascimento(d,m,a);
       //if(endereco == "") paciente.setEndereco(" ");
        paciente.setEndereco(endereco.toStdString());
       //if(email == "") paciente.setEmail(" ");
        paciente.setEmail(email.toStdString());

       ctrl.inclusaoPaciente(paciente);

    msg.setText(alerta);
    msg.setIcon(QMessageBox::Information);
    msg.exec();

   }catch(int valorErro){

       QString texto,valor;
       valor.setNum(valorErro);
       texto = QString::fromStdString(erro->getErro(valorErro));
       msg.setIcon(QMessageBox::Critical);
       msg.setText(texto);
       msg.exec();
   }catch(std::logic_error a){
       QMessageBox msg;
       QString texto;
       texto.fromStdString(a.what());

       msg.setText("Erro [5000] "+texto);
       msg.exec();
   }

}

void interface::on_edtListar_textChanged(QString texto )
{

/*    ui->listPaciente->clear();

    QStringList resultado = nomes.filter(texto,Qt::CaseInsensitive);


    for(int i=0;i<resultado.size();i++) {
       ui->listPaciente->insertItem(i,resultado.at(i));
    }
*/

}



void interface::on_btnMostrar_clicked()
{

    this->erro = PC3::ERROS::getInstancia(ui->boxIdioma->currentIndex());
    QMessageBox msg;
    InterfaceMostrar NovaJanela;
    PSP::Paciente paciente;

    try{
        if(ui->edtListar->text() == "")
            throw(13);// O campo nao contem nenhum nome
        paciente.setNome(ui->edtListar->text().toStdString());

        //ctrl.recuperarPaciente(paciente);

        NovaJanela.executar(paciente,ui->boxIdioma->currentIndex());

    }catch(int valorErro){

        QString texto,valor;
        valor.setNum(valorErro);
        texto = QString::fromStdString(erro->getErro(valorErro));
        msg.setIcon(QMessageBox::Critical);
        msg.setText(texto);
        msg.exec();
    }catch(std::logic_error a){
        QMessageBox msg;
        QString texto;
        texto.fromStdString(a.what());

        msg.setText("Erro [5000] "+texto);
        msg.exec();
    }

}

void interface::on_btnAlterar_clicked()
{
    this->erro = PC3::ERROS::getInstancia(ui->boxIdioma->currentIndex());

    QMessageBox msg;
    InterfaceAlterar NovaJanela;
    PSP::Paciente paciente;

    try{
        if(ui->edtListar->text() == "")
            throw(13);// O campo nao contem nenhum nome
        paciente.setNome(ui->edtListar->text().toStdString());
        if(!ctrl.buscarPaciente(paciente.getNome()))
            throw(11);

        NovaJanela.executar(paciente,ui->boxIdioma->currentIndex());

    }catch(int valorErro){

        QString texto,valor;
        valor.setNum(valorErro);
        texto = QString::fromStdString(erro->getErro(valorErro));
        msg.setIcon(QMessageBox::Critical);
        msg.setText(texto);
        msg.exec();
    }catch(std::logic_error a){
        QMessageBox msg;
        QString texto;
        texto.fromStdString(a.what());

        msg.setText("Erro [5000] "+texto);
        msg.exec();
    }

}
