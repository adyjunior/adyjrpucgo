#include "interfacemostrar.h"
#include "ui_interfacemostrar.h"



InterfaceMostrar::InterfaceMostrar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::InterfaceMostrar)
{
    ui->setupUi(this);
}

InterfaceMostrar::~InterfaceMostrar()
{
    delete ui;
}

void InterfaceMostrar::executar(PSP::Paciente  pac,int opcao){
    this->erro = PC3::ERROS::getInstancia(0);
    QMessageBox msg;

    try{

        this->mudarIdioma(opcao);

        ctrl.recuperarPaciente(pac);
        paciente = pac;

        QString cpf;
        cpf.setNum(pac.getNumeroCPF());

        int d,m,a;
        QString dia,mes,ano;
        paciente.getDataDeNascimento(d,m,a);
        dia.setNum(d);
        mes.setNum(m);
        ano.setNum(a);

        if(d < 10)dia = "0"+dia;
        if(m < 10)mes = "0"+mes;

        QString tel;
        tel.setNum(pac.getTelefone());

        //QMessageBox ab;ab.setText(QString::fromStdString(pac.getEndereco()));ab.exec();


        this->ui->lblSetNome->setText(QString::fromStdString(paciente.getNome()));
        this->ui->lblSetCPF->setText(cpf);
        this->ui->lblSetData->setText(dia+"/"+mes+"/"+ano);
        this->ui->lblSetEmail->setText(QString::fromStdString(paciente.getEmail()));
        this->ui->lblSetEndereco->setText(QString::fromStdString(paciente.getEndereco()));
        this->ui->lblSetTelefone->setText(tel);



        this->exec();
    }catch(int valorErro){

        QString texto,valor;
        valor.setNum(valorErro);
        texto = QString::fromStdString(erro->getErro(valorErro));
        msg.setText(texto);
        msg.setIcon(QMessageBox::Critical);
        msg.exec();
    }catch(std::logic_error a){

        QString texto;
        texto.fromStdString(a.what());

        msg.setText("Erro [5000] "+texto);
        msg.exec();
    }

}

void InterfaceMostrar::mudarIdioma(int opcao){

    switch(opcao){
    case 0:{
            ui->lblMostraNome->setText("Nome");
            ui->lblMostraCPF->setText("CPF");
            ui->lblMostraData->setText("Data de Nascimento");
            ui->lblMostraEndereco->setText("Endereco");
            ui->lblMostraTelefone->setText("Telefone");
            ui->lblMostraEmail->setText("Email");
            this->setWindowTitle("Sistema Paciente");
            break;
        }
    case 1:{
            ui->lblMostraNome->setText("Name");
            ui->lblMostraCPF->setText("CPF");
            ui->lblMostraData->setText("Date of birth");
            ui->lblMostraEndereco->setText("Address");
            ui->lblMostraTelefone->setText("Telephone");
            ui->lblMostraEmail->setText("Email");
            this->setWindowTitle("System Patients");
            break;
        }
    case 2:{
            ui->lblMostraNome->setText("Nombre");
            ui->lblMostraCPF->setText("CPF");
            ui->lblMostraData->setText("Fecha de nacimiento");
            ui->lblMostraEndereco->setText("Direcci�n");
            ui->lblMostraTelefone->setText("Tel�fono");
            ui->lblMostraEmail->setText("Email");
            this->setWindowTitle("Sistema de Pacientes");
            break;
        }
    case 3:{
            ui->lblMostraNome->setText("Name");
            ui->lblMostraCPF->setText("CPF");
            ui->lblMostraData->setText("Geburtsdatum");
            ui->lblMostraEndereco->setText("Adresse");
            ui->lblMostraTelefone->setText("Telefon");
            ui->lblMostraEmail->setText("E-Mail");
            this->setWindowTitle("System Patienten");
            break;
        }


    default :{

    }
}


}

