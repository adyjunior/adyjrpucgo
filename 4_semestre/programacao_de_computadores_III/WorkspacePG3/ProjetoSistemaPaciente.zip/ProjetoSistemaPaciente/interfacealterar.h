#ifndef INTERFACEALTERAR_H
#define INTERFACEALTERAR_H

#include <QDialog>
#include"Paciente.h"
#include"ERROS.h"
#include"CPF.h"
#include"Data.h"
#include"Paciente.h"
#include"Controle.h"
#include<QMessageBox>
#include<QString>


namespace Ui {
    class InterfaceAlterar;
}

class InterfaceAlterar : public QDialog
{
    Q_OBJECT

public:
    explicit InterfaceAlterar(QWidget *parent = 0);
    ~InterfaceAlterar();
    void executar(PSP::Paciente paciente,int opcao);
    void setarCampos(PSP::Paciente const & paciente)const;
    void mudarIdioma(int opcao);


private:

    PSP::Paciente paciente;
    PSP::Controle ctrl;
    PC3::ERROS *erro;
    Ui::InterfaceAlterar *ui;


private slots:
    void on_btnGravar_2_clicked();
};

#endif // INTERFACEALTERAR_H
