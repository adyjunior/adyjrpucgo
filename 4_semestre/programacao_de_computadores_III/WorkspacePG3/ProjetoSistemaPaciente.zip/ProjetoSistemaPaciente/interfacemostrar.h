#ifndef INTERFACEMOSTRAR_H
#define INTERFACEMOSTRAR_H

#include <QDialog>
#include"Paciente.h"
#include"Controle.h"
#include"ERROS.h"
#include<QMessageBox>
#include<QString>

namespace Ui {
    class InterfaceMostrar;
}

class InterfaceMostrar : public QDialog
{
    Q_OBJECT

public:
    explicit InterfaceMostrar(QWidget *parent = 0);
    ~InterfaceMostrar();
    void executar(PSP::Paciente  paciente,int opcao);
    void mudarIdioma(int opcao);

private:

    PSP::Paciente paciente;
    PSP::Controle ctrl;
    PC3::ERROS *erro;
    Ui::InterfaceMostrar *ui;


};

#endif // INTERFACEMOSTRAR_H
