#ifndef CONTROLE_H_
#define CONTROLE_H_
#include"Persistencia.h"

namespace PSP {

class Controle {
private:
        Persistencia *gravar;
public:
        Controle(){gravar = Persistencia::getInstancia("arquivoPaciente.txt");}
        void inclusaoPaciente(Paciente & paciente)const;
        void exclusaoPaciente(std::string const &nome)const;
        void alteracaoPaciente(Paciente &paciente)const;
        void recuperarPaciente(Paciente &paciente)const;
        bool buscarPaciente(std::string const &nome)const;
        Container::Iterator<Paciente*> *listarPaciente()const;
};

}

#endif /* CONTROLE_H_ */
