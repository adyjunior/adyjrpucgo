#include "interfacealterar.h"
#include "ui_interfacealterar.h"

InterfaceAlterar::InterfaceAlterar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::InterfaceAlterar)
{
    ui->setupUi(this);

    ui->AltEdtData->setFocus();
}

InterfaceAlterar::~InterfaceAlterar()
{
    delete ui;
}



void InterfaceAlterar::executar(PSP::Paciente paciente,int opcao){

    ctrl.recuperarPaciente(paciente);
    this->setarCampos(paciente);
    this->paciente = paciente;
    this->mudarIdioma(opcao);
    this->exec();

}

void InterfaceAlterar::setarCampos(PSP::Paciente const & paciente) const{
    QString tel,dia,mes,ano,cpf;
    int d,m,a;
    paciente.getDataDeNascimento(d,m,a);
    tel.setNum(paciente.getTelefone());
    cpf.setNum(paciente.getNumeroCPF());
    dia.setNum(d);
    mes.setNum(m);
    ano.setNum(a);

    if(d < 10)dia = "0"+dia;
    if(m < 10)mes = "0"+mes;

    this->ui->AltEdtNome->setText(QString::fromStdString(paciente.getNome()) );
    this->ui->AltEdtEmail->setText(QString::fromStdString(paciente.getEmail()));
    this->ui->AltEdtEndereco->setText(QString::fromStdString(paciente.getEndereco()));
    this->ui->AltEdtTelefone->setText(tel);
    this->ui->AltEdtCPF->setText(cpf);
    this->ui->AltEdtData->setText(dia+mes+ano);


}

void InterfaceAlterar::on_btnGravar_2_clicked()
{
    this->erro = PC3::ERROS::getInstancia(0);


   QString telefone = this->ui->AltEdtTelefone->text();
   QString numeroCPF = this->ui->AltEdtCPF->text();
   QString endereco = this->ui->AltEdtEndereco->text();
   QString email  = this->ui->AltEdtEmail->text();

   QMessageBox msg;

   try{
       int d=0,m=0,a=0;
       std::string data="";

       if( !(ui->AltEdtData->text() == "//") ){

           data = this->ui->AltEdtData->text().toStdString();


           d = atoi(data.substr(0,2).c_str());
           m = atoi(data.substr(3,2).c_str());
           a = atoi(data.substr(6,4).c_str());

       }






       if(telefone == "")this->paciente.setTelefone(0);
       else this->paciente.setTelefone(telefone.toLong());
       if(numeroCPF == "")this->paciente.setNumeroCPF(0);
       else this->paciente.setNumeroCPF(numeroCPF.toLongLong());
       if(data == "") this->paciente.setDataDeNascimento(1,10,5783);
       else this->paciente.setDataDeNascimento(d,m,a);

        this->paciente.setEndereco(endereco.toStdString());
        this->paciente.setEmail(email.toStdString());

       ctrl.alteracaoPaciente(paciente);

    msg.setText("Paciente foi Alterado com sucesso !");
    msg.setIcon(QMessageBox::Information);
    msg.exec();

    this->close();

   }catch(int valorErro){

       QString texto,valor;
       valor.setNum(valorErro);
       texto = QString::fromStdString(erro->getErro(valorErro));
       msg.setIcon(QMessageBox::Critical);
       msg.setText(texto);
       msg.exec();
   }catch(std::logic_error a){

       QString texto;
       texto.fromStdString(a.what());

       msg.setText("Erro [5000] "+texto);
       msg.exec();
   }

}


void InterfaceAlterar::mudarIdioma(int opcao){

    switch(opcao){
    case 0:{
            ui->AltLblNome->setText("Nome");
            ui->AltLblCPF->setText("CPF");
            ui->AltLblData->setText("Data de Nascimento");
            ui->AltLblEndereco->setText("Endereco");
            ui->AltLblTelefone->setText("Telefone");
            ui->AltLblEmail->setText("Email");
            ui->btnCancelar->setText("Cancelar");
            this->setWindowTitle("Sistema Paciente");
            break;
        }
    case 1:{
            ui->AltLblNome->setText("Name");
            ui->AltLblCPF->setText("CPF");
            ui->AltLblData->setText("Date of birth");
            ui->AltLblEndereco->setText("Address");
            ui->AltLblTelefone->setText("Telephone");
            ui->AltLblEmail->setText("Email");
            ui->btnCancelar->setText("Cancel");
            this->setWindowTitle("System Patients");
            break;
        }
    case 2:{
            ui->AltLblNome->setText("Nombre");
            ui->AltLblCPF->setText("CPF");
            ui->AltLblData->setText("Fecha de nacimiento");
            ui->AltLblEndereco->setText("Direcci�n");
            ui->AltLblTelefone->setText("Tel�fono");
            ui->AltLblEmail->setText("Email");
            ui->btnCancelar->setText("Cancelar");
            this->setWindowTitle("Sistema de Pacientes");
            break;
        }
    case 3:{
            ui->AltLblNome->setText("Name");
            ui->AltLblCPF->setText("CPF");
            ui->AltLblData->setText("Geburtsdatum");
            ui->AltLblEndereco->setText("Adresse");
            ui->AltLblTelefone->setText("Telefon");
            ui->AltLblEmail->setText("E-Mail");
            ui->btnCancelar->setText("Abbrechen");
            this->setWindowTitle("System Patienten");
            break;
        }


    default :{

    }
}


}
