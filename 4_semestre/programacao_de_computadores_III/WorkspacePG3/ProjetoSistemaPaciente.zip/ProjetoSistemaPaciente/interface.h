#ifndef INTERFACE_H
#define INTERFACE_H
#include"Data.h"
#include"CPF.h"
#include"ERROS.h"
#include"Paciente.h"
#include"Controle.h"
#include"Iterator.h"
#include<QMessageBox>
#include<QString>
#include<QStringList>
#include <QMainWindow>
#include<QListWidget>
#include<QListWidgetItem>
#include"interfacealterar.h"
#include"interfacemostrar.h"
#include "CDC.h"

namespace Ui {
    class interface;
}

class interface : public QMainWindow
{
    Q_OBJECT

public:
    explicit interface(QWidget *parent = 0);
    ~interface();

private:
    Ui::interface *ui;
    PSP::Controle ctrl;
    PC3::ERROS *erro;
    //QStringList nomes;

private slots:
    void on_btnAlterar_clicked();
    void on_btnMostrar_clicked();
    void on_edtListar_textChanged(QString texto );
    void gravarPaciente();
    void excluirPaciente();
    void listarPaciente();
    void alteraPaciente();
    void escolhaIdiomas();
    void texto();
};

#endif // INTERFACE_H
